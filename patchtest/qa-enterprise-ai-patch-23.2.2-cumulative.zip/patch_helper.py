"""Helper for APPLY_PATCH.ps1: run by the application's own Python (runtime\\python\\python.exe).

  manifest  record the replaced files in the app's MANIFEST.json, so VALIDATE_OFFLINE.cmd stays clean
  voice     make sure the offline voice agent works: the vosk engine, a speech model and the voice settings

Only the standard library is used. Nothing here needs the Internet.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import sysconfig
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

PATCH_VERSION = "23.2.2"
# The model the offline kit bundles (packaging/offline-lock.json, speech_model).
PINNED_MODEL = {"vosk-model-small-en-us-0.15.zip": "30f26242c4eb449f948e42cb302dd7a686cb29a3423a8367f99ff41780942498"}
# Vosk works only from a folder holding these two subfolders.
MODEL_PARTS = ("am", "conf")


def say(msg: str) -> None:
    print(f"  {msg}", flush=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while block := f.read(1 << 20):
            h.update(block)
    return h.hexdigest()


# --- manifest -------------------------------------------------------------------------------------------------

def cmd_manifest(args: argparse.Namespace) -> int:
    app = Path(args.app)
    path = app / "MANIFEST.json"
    if not path.exists():
        say("No MANIFEST.json (not an offline-kit install); nothing to record.")
        return 0
    manifest = json.loads(path.read_text(encoding="utf-8"))
    files = manifest.setdefault("files", {})
    rels = [line.strip().replace("\\", "/") for line in Path(args.files).read_text(encoding="utf-8-sig").splitlines()]
    for rel in filter(None, rels):
        target = app / rel
        if target.is_file():
            files[rel] = sha256(target)
    before = manifest.get("version", "unknown")
    manifest["version"] = PATCH_VERSION
    manifest.setdefault("patches", []).append({"patch": f"{PATCH_VERSION}-cumulative", "from": before,
                                              "applied_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                                              "files": len(rels)})
    path.write_text(json.dumps(manifest, indent=1, sort_keys=False), encoding="utf-8")
    say(f"MANIFEST.json updated: {len(rels)} files recorded, version {before} -> {PATCH_VERSION}.")
    return 0


# --- voice ----------------------------------------------------------------------------------------------------

def find_model(folder: Path) -> Path | None:
    def is_model(p: Path) -> bool:
        return p.is_dir() and all((p / part).is_dir() for part in MODEL_PARTS)

    if is_model(folder):
        return folder
    if folder.is_dir():
        for child in sorted(folder.iterdir()):
            if is_model(child):
                return child
    return None


def engine_ok() -> tuple[bool, str]:
    out = subprocess.run([sys.executable, "-E", "-s", "-c", "import vosk; print(vosk.__file__)"],
                         capture_output=True, text=True)
    lines = (out.stdout or out.stderr).strip().splitlines()
    return out.returncode == 0, lines[-1] if lines else ""


def install_engine(wheels: Path) -> None:
    whls = sorted(wheels.glob("*.whl"))
    if not whls:
        raise SystemExit("The patch's voice folder has no wheels. Extract the whole patch zip again.")
    pip = subprocess.run([sys.executable, "-E", "-s", "-m", "pip", "--version"], capture_output=True, text=True)
    if pip.returncode == 0:
        say("Installing the offline speech engine (vosk 0.3.45) from the patch, offline...")
        out = subprocess.run([sys.executable, "-E", "-s", "-m", "pip", "install", "--no-index", "--find-links",
                              str(wheels), "--disable-pip-version-check", "--no-warn-script-location", "vosk==0.3.45"],
                             capture_output=True, text=True)
        if out.returncode == 0:
            return
        say("pip could not install it; unpacking the wheels directly instead.")
    site = Path(sysconfig.get_paths()["purelib"])
    say(f"Unpacking the offline speech engine into {site}...")
    for whl in whls:
        with zipfile.ZipFile(whl) as z:
            for name in z.namelist():
                # Scripts and headers in <pkg>.data are not needed to import the package.
                if not name.split("/", 1)[0].endswith(".data"):
                    z.extract(name, site)


def kit_search_dirs(patch_dir: Path) -> list[Path]:
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    dirs = [patch_dir, patch_dir.parent, home / "Downloads", home / "Desktop", home / "Documents"]
    return [d for d in dirs if d.is_dir()]


def extract_speech_from_zip(zpath: Path, dest: Path, depth: int = 0) -> bool:
    """Copy the speech model out of a Vosk model zip, an offline kit zip, or a GitHub artifact zip holding the kit."""
    try:
        with zipfile.ZipFile(zpath) as z:
            names = z.namelist()
            marker = "payload/runtime/speech/"
            kit = [n for n in names if marker in n]
            if kit:
                prefix = kit[0][: kit[0].index(marker) + len(marker)]
                say(f"Copying the speech model out of {zpath.name}...")
                for n in kit:
                    rel = n[len(prefix):]
                    if not rel or n.endswith("/"):
                        continue
                    out = dest / rel
                    out.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(n) as src, out.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
                return find_model(dest) is not None
            if any(n.rstrip("/").endswith("/am") or "/am/" in n for n in names) and any("/conf/" in n for n in names):
                say(f"Unpacking the speech model {zpath.name}...")
                z.extractall(dest)
                return find_model(dest) is not None
            inner = [n for n in names if n.lower().endswith(".zip") and "aiagentictestagent-offline" in n.lower()]
            if inner and depth == 0:
                with tempfile.TemporaryDirectory() as tmp:
                    say(f"Opening the offline kit inside {zpath.name} (this takes a minute)...")
                    z.extract(inner[0], tmp)
                    return extract_speech_from_zip(Path(tmp) / inner[0], dest, depth + 1)
    except (zipfile.BadZipFile, OSError) as exc:
        say(f"Skipped {zpath.name}: {exc}")
    return False


def install_model(source: Path | None, patch_dir: Path, dest: Path) -> Path | None:
    tmp = dest.parent / (dest.name + ".incoming")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    candidates: list[Path] = []
    if source:
        candidates.append(source)
    for d in kit_search_dirs(patch_dir):
        candidates += sorted(d.glob("vosk-model*.zip")) + sorted(d.glob("vosk-model*"))
        candidates += sorted(d.glob("AIAgenticTestAgent-Offline*"), key=lambda p: p.stat().st_mtime, reverse=True)
    seen: set[Path] = set()
    for cand in candidates:
        if cand in seen or not cand.exists():
            continue
        seen.add(cand)
        ok = False
        if cand.is_dir():
            model = find_model(cand) or find_model(cand / "payload" / "runtime" / "speech") \
                or find_model(cand / "runtime" / "speech")
            if model:
                say(f"Copying the speech model from {model}...")
                shutil.copytree(model, tmp / model.name, dirs_exist_ok=True)
                ok = True
        elif cand.suffix.lower() == ".zip":
            pinned = PINNED_MODEL.get(cand.name)
            if pinned and sha256(cand) != pinned:
                say(f"{cand.name} does not match the pinned SHA-256; skipped.")
                continue
            ok = extract_speech_from_zip(cand, tmp)
        if ok and find_model(tmp):
            shutil.rmtree(dest, ignore_errors=True)
            tmp.rename(dest)
            return find_model(dest)
        shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True)
    shutil.rmtree(tmp, ignore_errors=True)
    return None


def cmd_voice(args: argparse.Namespace) -> int:
    app, data, patch_dir = Path(args.app), Path(args.data), Path(args.patch)
    problems = []

    ok, where = engine_ok()
    if ok:
        say(f"Offline speech engine: vosk is installed ({where}).")
    else:
        install_engine(patch_dir / "voice")
        ok, where = engine_ok()
        say("Offline speech engine: installed." if ok else f"Offline speech engine: still not importable ({where}).")
        if not ok:
            problems.append("the vosk speech engine could not be installed")

    settings_file = data / "settings.json"
    settings = json.loads(settings_file.read_text(encoding="utf-8")) if settings_file.exists() else {}
    voice = settings.get("voice") or {}
    configured = (voice.get("stt_model_dir") or "").strip()
    places = ([Path(configured)] if configured else []) + [app / "runtime" / "speech", data / "speech-model"]
    model = next((m for m in map(find_model, places) if m), None)
    if model:
        say(f"Speech model: {model}")
    else:
        say("No speech model on this PC yet; looking for one (the offline kit zip, or a vosk-model zip)...")
        model = install_model(Path(args.model) if args.model else None, patch_dir, data / "speech-model")
        if model:
            say(f"Speech model installed: {model}")
        else:
            problems.append("no speech model was found")

    changed = False
    if voice.get("stt_engine") in (None, "", "browser", "off") or (voice.get("stt_engine") == "local"
                                                                     and not (voice.get("stt_url") or "").strip()):
        voice["stt_engine"] = "builtin"
        changed = True
    if configured and not find_model(Path(configured)) and model:
        voice["stt_model_dir"] = ""   # a stale path would hide the working model
        changed = True
    if changed and settings_file.exists():
        shutil.copy2(settings_file, settings_file.with_name(f"settings.before-patch-{PATCH_VERSION}.json"))
        settings["voice"] = voice
        settings_file.write_text(json.dumps(settings, indent=2), encoding="utf-8")
        say("Voice settings: speech recognition set to the built-in offline recognizer.")
    else:
        say(f"Voice settings: recognizer '{voice.get('stt_engine') or 'builtin'}' kept.")

    if ok and model:
        test = subprocess.run([sys.executable, "-E", "-s", "-c",
                               "import sys,vosk; vosk.SetLogLevel(-1); vosk.Model(sys.argv[1]); print('loaded')",
                               str(model)], capture_output=True, text=True)
        if test.returncode == 0 and "loaded" in test.stdout:
            say("Offline voice check: the speech model loads. PASS")
        else:
            problems.append("the speech model did not load: " + (test.stderr.strip().splitlines() or ["?"])[-1])

    if problems:
        say("Offline voice check: NOT READY - " + "; ".join(problems) + ".")
        return 3
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("manifest")
    m.add_argument("--app", required=True)
    m.add_argument("--files", required=True)
    v = sub.add_parser("voice")
    v.add_argument("--app", required=True)
    v.add_argument("--data", required=True)
    v.add_argument("--patch", required=True)
    v.add_argument("--model", default="")
    args = ap.parse_args()
    return cmd_manifest(args) if args.cmd == "manifest" else cmd_voice(args)


if __name__ == "__main__":
    sys.exit(main())
