QA Enterprise AI - cumulative patch 23.2.2 (with the offline voice agent)
=========================================================================

One patch for any PC that runs 23.1.0, 23.2.0, 23.2.1 or 23.2.2. It brings it straight to 23.2.2,
the latest version: you do not need patches 23.2.0, 23.2.1 or 23.2.2 first.
No administrator rights, no Internet. Settings, TFS connection, database and reports are kept.

Install (Windows PowerShell)
----------------------------
1. Copy qa-enterprise-ai-patch-23.2.2-cumulative.zip to the PC, e.g. to Downloads.
2. Open PowerShell and run:

     cd $env:USERPROFILE\Downloads
     Unblock-File .\qa-enterprise-ai-patch-23.2.2-cumulative.zip
     Expand-Archive .\qa-enterprise-ai-patch-23.2.2-cumulative.zip -DestinationPath .\qa-patch-23.2.2 -Force
     powershell -ExecutionPolicy Bypass -File .\qa-patch-23.2.2\APPLY_PATCH.ps1

   (Or extract the zip and double-click APPLY_PATCH.cmd.)
3. When it says "Running ... version 23.2.2", press Ctrl+F5 once in the browser.

What the script does
--------------------
* Finds the installation (default %LOCALAPPDATA%\Programs\AIAgenticTestAgent; use -InstallDir for another folder).
* Stops the running application, backs up the files it replaces to <install>\patch-backups\, and copies the
  23.2.2 application files. If anything fails, the old files are restored automatically.
* Records the new files in MANIFEST.json, so VALIDATE_OFFLINE.cmd still reports every file as matching.
* Offline voice agent: checks the vosk speech engine (installs it from this zip if missing), finds the speech
  model (the one the offline kit installed in app\runtime\speech; if it is missing it copies it from the
  AIAgenticTestAgent-Offline-*.zip or a vosk-model-small-en-us-0.15.zip in Downloads, Desktop or Documents),
  sets speech recognition to the built-in offline recognizer, and checks the model loads.
* Starts the application and checks http://127.0.0.1:8765/api/health.
* Log: <install>\logs\patch-23.2.2-<time>.txt

If it says "Offline voice agent: NOT READY", run it again pointing at the offline kit zip you installed from:

     powershell -ExecutionPolicy Bypass -File .\qa-patch-23.2.2\APPLY_PATCH.ps1 -VoiceModel "C:\path\AIAgenticTestAgent-Offline-23.1.0.zip"

Undo: stop the application and copy the folders from <install>\patch-backups\<version>-to-23.2.2-<time>\ back
into <install>\app.

What 23.2.2 includes since 23.1.0
---------------------------------
23.2.0  Test Plans, Test Suites (11 testing types), Test Cases and Test Data pages; chunked test case generation
        with the generation timeout; concrete steps; tags; several suites at once; edit/delete; TFS Test Data
        Matrix; agentic voice (user story automation by voice) and the green tactical cockpit; agentic script
        chain (requirements -> discovery -> Playwright scripts).
23.2.1  Generated test cases are created in TFS automatically; faster generation; no stale pages after a patch.
23.2.2  Test data is generated four rows per AI call with the 10-minute generation timeout (no more timeouts).
