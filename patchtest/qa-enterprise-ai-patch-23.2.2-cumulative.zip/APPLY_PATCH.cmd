@echo off
rem Applies the QA Enterprise AI cumulative patch 23.2.2 (with the offline voice agent). No administrator rights needed.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_PATCH.ps1" %*
echo.
pause
