# AI Agentic Test Agent Enterprise

An AI agentic QA orchestration platform: requirements intelligence, test
design, Playwright automation, JMeter performance testing, self-healing,
defect intelligence with TFS / Azure DevOps traceability, voice commands and
reporting. It runs on a Windows PC online or fully offline, with no
administrator rights needed.

The platform is built in stages; see [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).
It never displays sample or demo data: every number comes from your configured
systems or from real runs.

## Test Plans, Test Suites, Test Cases and Test Data

Test plans can be created with or without a sprint, and updated and deleted in TFS. Test suites cover the 11 testing
types. Test cases are generated per suite type from a sprint's selected user stories, with acceptance-criterion
traceability and a coverage matrix. Test data is versioned and traceable, and is written to the TFS test data tab
or the Summary. See [docs/TEST_DESIGN_PAGES.md](docs/TEST_DESIGN_PAGES.md).

## Version 23.2.2: test data no longer times out

Test data used the short 2-minute AI timeout and asked a local model for all rows in one answer. It now asks for four
rows per call, each with the generation timeout, and keeps the rows already written when a later call times out. See
[docs/PATCH_23.2.2.md](docs/PATCH_23.2.2.md).

## Version 23.2.1: generated test cases are created in TFS

Generated test cases without errors are now created in the selected suite as soon as generation ends (option
**Create in TFS when done**); before, they waited for a click on *Create selected test cases in this suite*. The slow
second AI pass only runs for errors, uncovered criteria, summary steps and vague results, unless **Thorough review**
is checked. The browser now always loads the pages of the installed version after a patch. See
[docs/PATCH_23.2.1.md](docs/PATCH_23.2.1.md).

## Version 23.2.0: test case and test data fixes

Large user stories are generated two acceptance criteria per AI call with a separate generation timeout, so a local
model no longer times out; a criterion that still fails is reported and the rest are kept. Steps must name the page,
field or button and the value used. Cases are tagged with their testing type and user story, several suites can be
generated at once, and the Test Cases list can edit, delete, select all and delete selected. Test Data loads the data
already in the TFS Test Data tab, writes a Test Data Matrix there, generates for selected cases or several stories,
and coverage recognises test cases created outside the application. Updating from 23.1.0 needs only the patch zip
(see [docs/PATCH_23.2.0.md](docs/PATCH_23.2.0.md)).

## Version 23.1.0: offline install kit for company PCs

The offline package now bundles llama-server, opens a **First-Run Setup** screen that asks only for the TFS URL,
project and PAT, the `.gguf` model file and (optionally) a voice model, and ships a CycloneDX SBOM, a `SHA256SUMS.txt`
for the zip and Python packages without known vulnerabilities (checked by `pip-audit` in CI). How to hand it to a
security team and install it is in [docs/OFFLINE_INSTALL.md](docs/OFFLINE_INSTALL.md).

## Version 23.0.0: Command Center

The AI Voice Command Center, the HUD theme, real agent states, allow-listed voice commands with an offline
radio voice, the synchronized playback cursor, `pick_date`, voice commands while recording and the Managed
Local LLM are described in [docs/COMMAND_CENTER_UPGRADE.md](docs/COMMAND_CENTER_UPGRADE.md) (including install,
rollback and what to verify on Windows). [docs/CAPABILITY_INVENTORY.md](docs/CAPABILITY_INVENTORY.md) lists every
capability.

## Quick start (development)

```
SETUP_DEV.cmd          # creates .venv and installs requirements (per user)
START_QA_PLATFORM.cmd  # starts the runtime and opens http://127.0.0.1:8765/
```

On Linux or macOS:

```
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt
python -m qa_platform
```

Run the tests with `python -m pytest`.

## Data and settings

Runtime data (SQLite database, logs, evidence, reports, `settings.json`) lives
in `data/` next to the app, or in the folder named by `QA_HOME`. It is
git-ignored. Secrets are never written to `settings.json` or logs.

## What works in Stage 1

* Dashboard shell with navigation, light/dark theme (saved), live connection indicator
* Agent Workflow page: 18 agents with role-specific robots, status driven only by runtime events,
  Live Agent Activity stream over SSE
* Notification bell with real unread counts
* Execution History with run details
* System diagnostics run by the QA Orchestration Agent (Python, data folder, database,
  Playwright, Java, JMeter, On-Premise AI server, TFS profile)
* Structured JSON errors on every endpoint, JSON logs with secret redaction

## What works in Stage 2

* TFS Connection settings for **Azure DevOps Online** and **Local TFS / Azure DevOps Server**, with one active profile.
  The PAT is write-only and stored in the Windows Credential Manager.
* Connection test with PASS/FAIL and the exact reason for: Server Reachability, Authentication,
  Organization/Collection, Project, Work Item API, Test Management API
* TFS Explorer (scoped to the active profile's project) with Sprint/Iteration, Work Item Type, State, Assigned To and ID/title filters, plus a detail
  panel with acceptance criteria and traceability (linked test cases, defects, other links)
* User Stories, Acceptance Criteria, Test Cases, Defects, Test Plans and Test Suites pages on real TFS data, with
  create/edit written back to TFS
* Work item types come from the project's process categories, so "Bug", "Defect" or "Issue" are detected rather
  than hard-coded; fields missing from a process template are skipped instead of failing the save
* Dashboard KPIs (user stories, test cases, open defects) from the active project, cached for 60 seconds

## What works in Stage 3

* **On-Premise AI** settings (server URL, model, timeout, temperature, max tokens) with diagnostics:
  Configuration, Server Reachability, Model Loaded, Completion, Structured JSON Output. Works with any
  OpenAI-compatible local server (llama.cpp `llama-server` with a Qwen GGUF model, Ollama). No Internet, no downloads.
* **AI Test Design** from a user story: Requirements Intelligence, Test Planning & Strategy, Test Case Design and
  Test Data Intelligence agents run in turn and stream their progress to Agent Workflow
* Review the generated requirements, ambiguities, strategy, test cases (steps and expected results) and datasets,
  then the Test Suite Design Agent creates the selected test cases in TFS with steps, a "Tested By" link to the
  story, and optionally adds them to a test plan suite
* **Test Data** page: datasets linked to their TFS test cases, editable
* If the AI server is unavailable the agents fail with the reason; nothing is generated without it

## What works in Stage 4

* **Automation Studio** with four ways to create Playwright automation, all producing the same versioned script
  format and running through one runner:
  * **AI-Driven Automation**: the Automation Engineering Agent reads a TFS test case's steps and maps them to
    elements actually discovered on your application. Selectors it cannot verify are listed on the script for review.
  * **Guided Browser Automation**: a browser opens on your PC and records clicks, typing, selections and checks.
    Typed passwords are never stored; they become `{{CRED:role.password}}`.
  * **Application Discovery & Update**: crawls same-site pages (logout links skipped), inventories elements, forms
    and the XHR/fetch API endpoints the pages call, and shows what changed since the previous discovery. Build a
    script from selected elements. With **TFS + Application** it runs the whole agentic chain: read the selected TFS
    requirements (Epic / Feature / User Story / Acceptance Criteria / Test Case), discover the application (signing
    in, pausing for OTP or unknown values), map requirements to pages and elements with coverage and gaps, then
    generate the Playwright scripts of the Test Cases in scope through AI-Driven Automation (option on by default;
    also a *Generate Playwright Scripts* button on the coverage page).
  * **Hybrid Test Automation**: record extra steps into any script at any position.
* **Script editor**: steps table, runtime values (`{{TODAY+3d:%d/%m/%Y}}`, `{{DATA:field}}`, `{{CRED:role.username}}`),
  readable Playwright Python export, version history with restore, and archive instead of delete.
* **Execution** with visual playback: a cursor, element highlight and click ripple are injected into the browser at
  run time (never into the application's code), plus screenshots per failure and at the end, optional video, and
  steps with timings in Execution History.
* **Self-healing**: only after the recorded locator and its alternates fail, candidates from the live page are scored
  against the recorded fingerprint. A match is used only above 0.62 confidence and clearly ahead of the runner-up.
  Every attempt is stored with candidates and a screenshot. The script changes only when you apply a healing whose
  run then passed, and the previous version is kept.
* **Application Credentials**: role-based logins per application. Passwords are kept in the Windows Credential
  Manager, separate from the TFS PAT, resolved only at run time and masked in logs and evidence.

## What works in Stage 5

* **Performance Test Plans** for Load, Stress, Spike and Soak tests: HTTP requests (method, URL, body, headers,
  expected status code and text), users, ramp-up, duration, think time, stress steps or spike window, and SLAs
  (average, 90th/95th/99th percentile, error rate, throughput).
* Create a plan from an **Application Discovery** (its successful pages and observed GET API endpoints) or enter
  requests manually. Download the generated JMX to open it in JMeter.
* **Run with JMeter in non-GUI mode** with live progress on Agent Workflow, and stop a run at any time (results so far
  are kept). Java and JMeter are found from Performance settings, the portable package's `runtime` folder,
  `JAVA_HOME` / `JMETER_HOME`, or PATH.
* **Performance Results**: samples, error rate, average and percentiles and throughput; charts of response time,
  throughput, errors and active users over time; a per-request table with response codes and most frequent errors, SLA checks per
  request and overall, and JMeter's own HTML dashboard.
* **AI performance analysis** (On-Premise AI): observations and suspected bottlenecks that cite the measured values,
  and what cannot be determined from the results.

## What works in Stage 6

* When an automated test fails, or a performance run fails its SLAs, the **Failure & Quality Analysis Agent**
  classifies what the run recorded (assertion, navigation, interaction, locator, test setup, error rate, latency,
  throughput) and drafts a defect: title, severity, steps to reproduce, the error, the element, the environment and the
  failure screenshot. It never states a root cause the evidence does not show.
* The **Defect Intelligence Agent** compares each draft with the open defects in TFS (wording, the same element, the
  same linked test case) and lists likely and possible duplicates. The same failure seen again adds an occurrence to the
  existing draft and, once it is in TFS, a comment on that defect instead of a new one.
* **Defect creation** mode on **Defect Review**: *Review Before Create* (default), *Automatic* (product failures with
  no likely duplicate are created right away; locator and test setup failures still wait) or *Disabled*.
* **Create in TFS** uses your process's defect type (Bug, Defect or Issue), maps severity to its allowed values, skips
  fields the process does not have and lists them, attaches screenshots, and links the defect to the test case and
  user story. You can also link a draft to an existing defect or dismiss it with a reason.
* **Analyze failure** on a failed run in Execution History or Performance Results drafts a defect on demand.

## What works in Stage 7

* **Voice Commands**: press the microphone (on the Voice Commands page or in the top bar on any page) and speak, or
  type the command. The Voice Command Agent acknowledges by voice, runs the action through the same services the
  pages use, follows it while it runs, and speaks the result, for example "The test execution failed at step 8. I found
  a locator failure on the checkout button" or "The performance test completed successfully. P95 response time was
  1.4 seconds and the error rate was 0.2 percent."
* Supported commands: open any page, open a user story / test case / defect by number, generate test cases, generate
  automation, run or play a test case or a named test, run all automated tests, start a browser recording, run a
  performance test (with the users and duration you say, for that run only), stop the running test, show failed tests,
  show the performance report, analyze the failure, create defects for failed tests, and status. Anything else gets
  "I cannot perform that instruction because no supported QA action is mapped to it."
* Follow-ups use the conversation's context and the page you are on: "open user story 118", then "generate test
  cases"; "run test case 1280", then "run it again". A missing detail is asked for ("Which test case?").
  Creating defects in TFS asks you to say confirm first.
* **Speech recognition**: the built-in offline recognizer (default; a small Vosk English model bundled in the offline
  package under `runtime\speech`, so the microphone works with no Internet and no speech server), a local whisper.cpp
  server or any OpenAI-compatible speech server, the browser's recognition (needs Internet in Chrome and Edge), or off
  (typed commands only). "JMeter" is understood however the recognizer spells it ("j meter", "jay meter").
  Sentences outside the fixed phrases are mapped by the On-Premise AI when it is available; it can only choose a
  supported command and never adds an ID you did not say.
* **Spoken replies** use voices installed on the PC only, so they work without Internet. The default **pilot radio**
  style answers like a pilot on the radio: "Roger, sir. Stand by." as soon as you stop talking, then "Copy, sir.
  Starting test case creation." once the command is understood, with squelch, static and a roger beep. The reply is
  rendered by a Windows voice (adult male by default) and played through a radio filter; without Windows voices the
  browser's voice is used with the static around it. Choose "Plain voice" under Systems Configuration to turn it off.
* The Voice Commands page is a cockpit-style console: radar scope with the microphone, live microphone level,
  RECEIVING / PROCESSING / TRANSMITTING status, and a comms log.

## What works in Stage 8

* **Dashboard KPIs** now all come from real data: User Stories, Acceptance Criteria (counted from the criteria written
  on your user stories), Test Cases and Open Defects live from TFS; Test Data, Automated, Not Automated and Automation
  Coverage from saved data sets, automated tests and the TFS test case count; Passed, Failed and Functional Pass Rate
  from the latest result of each automated test; Performance Tests, Performance Failures and Performance SLA Pass Rate
  from finished JMeter runs. A figure that cannot be measured shows "—" with the reason.
* **Analytics** (Quality → Analytics): automation coverage, pass and failure rate, not automated, executions per day,
  defects drafted per day, flaky tests (tests that both passed and failed, with how often the result flipped), and
  self-healing per day and per test. Performance: P95, P99, throughput and error rate per run, SLA pass and fail,
  maximum tested concurrency, and, for one plan, each request's P95 in the latest run against the previous run.
  Periods are 7, 14, 30 or 90 days of the PC's local calendar.
* **Reports** (Quality → Reports): choose functional, performance or both, the period, optionally a user story and up
  to five performance runs. The Reporting & Analytics Agent builds an HTML report and prints the same page to PDF with
  the bundled Chromium (offline). Functional sections: executive summary, coverage, trends, user story, acceptance
  criteria, test cases with automation and test data, execution results (passed, failed, not run), defects,
  self-healing and failure screenshots. Performance sections: summary, load profile, response times with P90/P95/P99,
  throughput, error rate, graphs, transaction results, SLA compliance, performance defects and the AI analysis when one
  was requested. Reports are listed with View, HTML, PDF and Delete; a notification says when one is ready.

## What works in Stage 9

* **Offline portable Windows package.** On a 64-bit Windows PC with Internet and Python 3.10+, double-click
  `BUILD_OFFLINE_PACKAGE.cmd`, or run
  `py -3 packaging\build_offline_package.py [--zip] [--ai-dir <folder with a Qwen GGUF model>]`. It writes
  `dist_offline\AIAgenticTestAgent-Offline-<version>\` with `INSTALL_OFFLINE.cmd`, `VALIDATE_OFFLINE.cmd`,
  `README_OFFLINE.txt` and `payload\` (the application, `runtime\python`, `runtime\jre`, `runtime\apache-jmeter-5.6.3`,
  `runtime\ms-playwright`, `runtime\ai\llama.cpp` (llama-server), `MANIFEST.json` with the SHA-256 of every file,
  `DEPENDENCIES.md` and `sbom.cdx.json`).
  Python, the Temurin JRE, JMeter, llama-server and the speech model are pinned with checksums in
  `packaging/offline-lock.json` (`packaging/update_pins.py` refreshes the Java and llama-server pins);
  Python packages come from `packaging/requirements-offline-win.txt` with `--require-hashes`. Models are never
  downloaded: `--ai-dir` copies the folder you give it.
* **VALIDATE_OFFLINE.cmd** checks Windows, administrator rights (not needed), every package file against the manifest,
  the bundled Python and packages, Java, JMeter, a headless Chromium launch, Windows Credential Manager, the data
  folder, the dashboard port and the On-Premise AI files, all with outbound network connections blocked. The report is
  saved to a text file and contains no secrets.
* **INSTALL_OFFLINE.cmd** installs for the current Windows user (default `%LOCALAPPDATA%\Programs\AIAgenticTestAgent`,
  `--target` for another folder) without administrator rights. It verifies the package, copies the new version beside
  the current one, switches over, runs the full validation and switches back automatically if anything fails. The
  data folder is shared between versions and never touched; credentials stay in Windows Credential Manager. Logs go to
  `logs\`. `ROLLBACK_OFFLINE.cmd` in the install folder returns to the previous version.
* CI builds the package on Windows, validates it, installs it to a temporary folder and validates the installed copy.
  The tested package is attached to each run as the artifact `AIAgenticTestAgent-Offline-windows` (kept 14 days):
  GitHub → Actions → the latest CI run → Artifacts. `AIAgenticTestAgent-Offline-windows-zip` holds the same package
  as one zip with `SHA256SUMS.txt` and `sbom.cdx.json`, for a security scan.

## TFS test generation and Python test scripts

* **Test plan in TFS.** When you save a test design to TFS, choose *Create or reuse "<project> - <sprint> - Test Plan"*.
  The plan gets the story's sprint and area and the AI test strategy as its description. A plan with the same name is
  reused. The **Test Plans** page can also create a plan for a user story without a test design.
* **Default testing-type suites.** Under the plan's root suite: Functional, Positive, Negative, Boundary / Edge Case,
  End-to-End and Smoke Testing. Existing suites with these names are reused, never duplicated.
* **Test cases with steps.** Each test case is created with its action/expected-result steps, a "Tested By" link to the
  user story, a title like "Negative Testing - …", and is added to the suite of its testing type.
* **Test data in TFS.** Each test case's **Summary** gets a Test Data table (one row per data set), and its
  **Parameter values** get the same data (one row per data set, so Azure Test Runner runs one iteration per row).
  Both are optional. After editing test data on the **Test Data** page, *Write to TFS* updates the test case again.
* **Python automation scripts.** Every automation script can be downloaded as a standalone **pytest + Playwright** test
  (`test_tc<id>_<title>.py`), with one test per data set of its TFS test case. It also runs with plain
  `python <file>.py`. Passwords are read from environment variables (for example `ADMIN_PASSWORD`) and never written
  into the file. *Download ready-to-run .zip* adds `pytest.ini`, `requirements.txt`, `README.txt` and `RUN_TESTS.cmd`,
  which uses the platform's own Python and browsers, so it works on the offline package too (pytest is included).
* **AI-Driven Automation for a whole user story**: enter a User Story ID instead of a Test Case ID to create one script
  per linked test case, then download them all as one zip.

## AI-Driven Automation Script Studio

**Automation Studio → AI-Driven Automation** turns TFS User Stories and Test Cases into a maintainable
**Python + Playwright** framework (Page Object Model, business flows, tests, test data, fixtures, utilities) in the
data folder's `automation-workspace\`. Every path in it is relative, so the folder (or *Download framework (.zip)*)
runs on another Windows PC with `RUN_TESTS.cmd`.

* **Generate Automation.** Pick a Sprint, then tick User Stories (all their Test Cases) or open a story and pick Test
  Cases; several stories can be generated in one job. The job page shows progress and a status per Test Case
  (Retry, View Details, Open Logs, Stop). Test Cases that already have automation ask whether to open, regenerate
  (only what changed), keep a new version or skip.
* **The Automation Engineering Agent** asks the AI (On-Premise or Cloud, see *Settings → AI Runtime*) only to map
  each Test Case step to page elements; the Python is written deterministically from that mapping. Existing Page
  Objects, flows and fixtures are reused; only missing methods, pages and flows are added. Before anything is saved,
  a copy of the framework is checked: syntax, imports, undefined names, Page Object / flow / fixture / test data
  references, method signatures of every test that uses a changed Page Object, Playwright usage, traceability, and
  `pytest --collect-only`. Files are written atomically and verified on disk; a script is shown as GENERATED only
  when its `.py` file exists (otherwise FILE MISSING). The previous working version is kept if generation fails.
* **Script Inventory** (newest first): Method, User Story, Test Case, Sprint, Script, Generated, Status, Last Result
  and the actions View Script, Edit Script, Flow Logic, Play, Result, Logs, Evidence, Regenerate / Update.
  *Play Selected* asks once for the mode (Headless recommended) and runs each script separately.
* **Per script:** View Script (highlighted Python and traceability), Edit Script (validated, backed up and versioned),
  Flow Logic (rename, reorder, remove or add business steps), Test Data (combinations and date/time rules from the
  Windows clock, e.g. `{{TODAY+7d:%d/%m/%Y}}`), Credentials (a script-specific override wins over the application
  credentials; passwords stay in Windows Credential Manager), Components (shared Page Objects and flows with impact
  analysis), History (view, compare, restore).
* **Play** asks *Visible Browser Execution* (moving cursor, element highlight, visible typing; passwords are never
  shown) or *Background / Headless Execution* (the same script). The status turns RUNNING at once and a live panel
  shows the Test Execution Agent, Test Case, mode, current step and elapsed time; **Stop** ends the run and its
  browser, keeps the evidence and marks it STOPPED. Results are PASSED, FAILED, STOPPED or ERROR.
* **Evidence** of each run (never overwritten) in `data\evidence\<run id>\`: `result.json`, `execution.log`,
  `progress.jsonl`, `junit.xml`, `trace.zip` files, `screenshots\` with one screenshot per step
  (`<data set>-step_001_<step>.png`) and, for a failed step, `..._FAILED.png` (failing element outlined) and
  `..._FAILED_full.png`. **Result** shows every step with its expected result (from TFS), actual result, status, time,
  duration and screenshot; **Evidence** shows the screenshots in order; **Logs** shows the execution log (secrets
  masked) and the generation log.
* **Failure & Quality Analysis.** A failed run is classified as Application Functional Defect, Automation Script Defect,
  Locator Changed, Test Data Problem, Environment Failure, Authentication Failure, Network/API Failure, Timeout,
  Expected Result Mismatch, Application Performance Problem or Unknown - Manual Investigation Required, with a
  confidence, what was observed (page, messages, console errors, failed requests, self-healing attempts) and the next
  step (`failure-analysis.json`). Only likely application problems become a defect draft in **Defect Review**;
  script, data, credential, environment and locator problems never do.
* **Self-healing** records the original locator, replacement, confidence, page, time, Test Case and result. The Page
  Object is changed only when you choose *Update Page Object* after a passing run, as a new version.
* The single-script AI generation page used before stays available from links to its scripts
  (`#/ai-automation-classic`).
