"""Voice Command API: commands (spoken or typed), local speech recognition, settings, diagnostics, history."""

from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Depends, Query, Request, Response
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from ..errors import QAError
from ..runtime import Runtime
from .deps import runtime

router = APIRouter(prefix="/api/voice")

MAX_AUDIO_BYTES = 10 * 1024 * 1024


class PageIn(BaseModel):
    route: str = Field(default="", max_length=60)
    params: dict[str, str] = {}


class CommandIn(BaseModel):
    text: str = Field(min_length=1, max_length=500)
    conversation_id: str = Field(min_length=8, max_length=64, pattern=r"^[\w-]+$")
    source: Literal["speech", "typed"] = "typed"
    page: PageIn | None = None


class VoiceSettingsIn(BaseModel):
    stt_engine: Literal["builtin", "local", "browser", "off"] | None = None
    stt_model_dir: str | None = Field(default=None, max_length=400)
    stt_url: str | None = Field(default=None, max_length=300)
    stt_api: Literal["whisper_cpp", "openai"] | None = None
    stt_model: str | None = Field(default=None, max_length=120)
    language: str | None = Field(default=None, pattern=r"^[a-z]{2}(-[A-Za-z]{2})?$")
    speak_replies: bool | None = None
    tts_voice: str | None = Field(default=None, max_length=200)
    tts_rate: float | None = Field(default=None, ge=0.5, le=2)
    reply_style: Literal["radio", "plain"] | None = None
    radio_voice: str | None = Field(default=None, max_length=200)
    agent_display_name: str | None = Field(default=None, min_length=1, max_length=40)
    agent_command_name: str | None = Field(default=None, min_length=2, max_length=30, pattern=r"^[A-Za-z][A-Za-z' -]*$")
    voice_enabled: bool | None = None
    listen_mode: Literal["push_to_talk", "wake_name"] | None = None
    phrase_style: Literal["standard", "tactical"] | None = None
    radio_intensity: float | None = Field(default=None, ge=0, le=1)
    wireless_tone: bool | None = None
    static_volume: float | None = Field(default=None, ge=0, le=1)
    ambience_enabled: bool | None = None
    ambience_volume: float | None = Field(default=None, ge=0, le=1)
    voice_volume: float | None = Field(default=None, ge=0, le=1)


class SpeakIn(BaseModel):
    text: str = Field(min_length=1, max_length=600)


@router.post("/commands")
def command(body: CommandIn, rt: Runtime = Depends(runtime)) -> dict[str, Any]:
    page = body.page.model_dump() if body.page else None
    return {"ok": True, **rt.voice.handle(body.text, conversation_id=body.conversation_id, source=body.source, page=page)}


@router.get("/commands")
def history(conversation_id: str | None = Query(default=None, max_length=64), limit: int = Query(default=50, ge=1, le=200),
            rt: Runtime = Depends(runtime)) -> dict[str, Any]:
    items = rt.voice.history(conversation_id, limit)
    return {"ok": True, "items": items, "context": rt.voice.context(conversation_id) if conversation_id else None}


@router.post("/transcribe")
async def transcribe(request: Request, rt: Runtime = Depends(runtime)) -> dict[str, Any]:
    """Raw audio body (16 kHz mono WAV from the dashboard) -> text from the local speech server."""
    audio = await request.body()
    if len(audio) > MAX_AUDIO_BYTES:
        raise QAError("VOICE_AUDIO_TOO_LARGE", "The recording is too long. Keep commands under a minute.", status=413)
    content_type = request.headers.get("content-type", "audio/wav").split(";")[0]
    text = await run_in_threadpool(rt.voice.transcribe, audio, content_type)
    return {"ok": True, "text": text}


@router.post("/warmup")
def warmup(rt: Runtime = Depends(runtime)) -> dict[str, Any]:
    """Load the offline speech model in the background (it is kept for the whole session)."""
    import threading

    if rt.voice.config().get("stt_engine") != "builtin":
        return {"ok": True, "loading": False}
    threading.Thread(target=rt.voice.offline.warm, name="speech-warmup", daemon=True).start()
    return {"ok": True, "loading": True}


@router.get("/radio-voices")
def radio_voices(rt: Runtime = Depends(runtime)) -> dict[str, Any]:
    return {"ok": True, **rt.voice.radio_voices()}


@router.post("/speak")
async def speak(body: SpeakIn, rt: Runtime = Depends(runtime)) -> Response:
    """A reply spoken by a Windows voice as WAV, for the dashboard's radio effect."""
    audio = await run_in_threadpool(rt.voice.speak, body.text)
    return Response(audio, media_type="audio/wav", headers={"Cache-Control": "no-store"})


@router.get("/settings")
def get_settings(rt: Runtime = Depends(runtime)) -> dict[str, Any]:
    return {"ok": True, **rt.voice.config()}


@router.put("/settings")
def put_settings(body: VoiceSettingsIn, rt: Runtime = Depends(runtime)) -> dict[str, Any]:
    patch = body.model_dump(exclude_none=True)
    for key in ("agent_display_name", "agent_command_name"):
        if key in patch:
            patch[key] = " ".join(patch[key].split())
            if not patch[key]:
                raise QAError("VOICE_NAME_INVALID", "The agent name cannot be empty.")
    if "stt_url" in patch:
        patch["stt_url"] = patch["stt_url"].strip().rstrip("/")
        if patch["stt_url"] and not patch["stt_url"].lower().startswith(("http://", "https://")):
            raise QAError("VOICE_URL_INVALID", "The speech server URL must start with http:// or https://.")
    rt.settings.update({"voice": patch})
    return {"ok": True, **rt.voice.config()}


@router.post("/diagnostics")
def diagnostics(rt: Runtime = Depends(runtime)) -> dict[str, Any]:
    return {"ok": True, **rt.voice.diagnostics()}
