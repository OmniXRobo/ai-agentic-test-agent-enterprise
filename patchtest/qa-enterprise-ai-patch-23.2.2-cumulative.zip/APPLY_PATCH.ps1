<#
  QA Enterprise AI - cumulative patch to 23.2.2, with the offline voice agent.

  Brings an installation of 23.1.0, 23.2.0, 23.2.1 or 23.2.2 to 23.2.2 in one step:
    * stops the running application, backs up the files it replaces, copies the 23.2.2 application files,
    * records them in MANIFEST.json so VALIDATE_OFFLINE.cmd stays clean,
    * makes sure the offline voice agent works (vosk engine, speech model, built-in offline recognizer),
    * starts the application again and checks /api/health.
  Settings, database, evidence and reports in the data folder are kept. No administrator rights and no Internet.
  If anything fails while files are replaced, the previous files are restored automatically.

  Usage (PowerShell, in the extracted patch folder):
    powershell -ExecutionPolicy Bypass -File .\APPLY_PATCH.ps1
    powershell -ExecutionPolicy Bypass -File .\APPLY_PATCH.ps1 -InstallDir "D:\Apps\AIAgenticTestAgent"
    powershell -ExecutionPolicy Bypass -File .\APPLY_PATCH.ps1 -VoiceModel "C:\Users\me\Downloads\AIAgenticTestAgent-Offline-23.1.0.zip"
#>
[CmdletBinding()]
param(
    [string]$InstallDir = "",
    [string]$VoiceModel = "",
    [switch]$NoStart
)

$ErrorActionPreference = "Stop"
$PatchVersion = "23.2.2"
$Here = $PSScriptRoot

function Say([string]$msg) { Write-Host $msg }
function Step([string]$msg) { Write-Host ""; Write-Host "== $msg" -ForegroundColor Cyan }
function Fail([string]$msg) { Write-Host ""; Write-Host "PATCH FAILED: $msg" -ForegroundColor Red; exit 1 }

# --- 1. Find the installation ------------------------------------------------------------------------------------
Step "Finding QA Enterprise AI"
$roots = @()
if ($InstallDir) { $roots += $InstallDir }
$roots += (Join-Path $env:LOCALAPPDATA "Programs\AIAgenticTestAgent")
$App = $null
foreach ($r in $roots) {
    if (Test-Path (Join-Path $r "app\qa_platform\__init__.py")) { $App = (Resolve-Path (Join-Path $r "app")).Path; break }
    if (Test-Path (Join-Path $r "qa_platform\__init__.py")) { $App = (Resolve-Path $r).Path; break }
}
if (-not $App) { Fail "No installation found in: $($roots -join '; '). Run again with -InstallDir ""<folder that holds app or qa_platform>""." }
if (-not (Test-Path (Join-Path $Here "app\qa_platform\__init__.py"))) { Fail "The patch folder is incomplete. Extract the whole zip again." }

$Installed = Test-Path (Join-Path $App "INSTALLED.json")
if ($Installed) { $Root = Split-Path $App -Parent; $Data = Join-Path $Root "data" } else { $Root = $App; $Data = Join-Path $App "data" }
if ($env:QA_HOME) { $Data = $env:QA_HOME }

$Py = Join-Path $App "runtime\python\python.exe"
if (-not (Test-Path $Py)) { $Py = Join-Path $App ".venv\Scripts\python.exe" }
if (-not (Test-Path $Py)) { Fail "The application's Python was not found in $App\runtime\python or $App\.venv." }

$init = Get-Content (Join-Path $App "qa_platform\__init__.py") -Raw
$Before = if ($init -match '__version__\s*=\s*"([^"]+)"') { $Matches[1] } else { "unknown" }
Say "Application folder : $App"
Say "Data folder        : $Data  (kept as it is)"
Say "Installed version  : $Before  ->  $PatchVersion"

$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$LogDir = Join-Path $Root "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir "patch-$PatchVersion-$Stamp.txt"
try { Start-Transcript -Path $Log -Append | Out-Null } catch { }

# --- 2. Stop the running application -----------------------------------------------------------------------------
Step "Stopping the application"
$Port = 8765
$settingsFile = Join-Path $Data "settings.json"
if (Test-Path $settingsFile) {
    try { $p = (Get-Content $settingsFile -Raw | ConvertFrom-Json).server.port; if ($p) { $Port = [int]$p } } catch { }
}
$pids = @()
try { $pids += (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue).OwningProcess } catch { }
$pids += (Get-Process -Name python, pythonw -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($App, [StringComparison]::OrdinalIgnoreCase) }).Id
$pids = $pids | Where-Object { $_ -and $_ -ne 0 } | Sort-Object -Unique
foreach ($id in $pids) {
    $proc = Get-Process -Id $id -ErrorAction SilentlyContinue
    if ($proc) { Say "Stopping $($proc.ProcessName) (PID $id)"; Stop-Process -Id $id -Force -ErrorAction SilentlyContinue }
}
if ($pids) { Start-Sleep -Seconds 3 } else { Say "It was not running." }

# --- 3. Back up and replace the application files ----------------------------------------------------------------
Step "Backing up the files this patch replaces"
$Backup = Join-Path $Root "patch-backups\$Before-to-$PatchVersion-$Stamp"
New-Item -ItemType Directory -Force -Path $Backup | Out-Null
$items = Get-ChildItem (Join-Path $Here "app") | ForEach-Object { $_.Name }
foreach ($name in ($items + "MANIFEST.json")) {
    $src = Join-Path $App $name
    if (Test-Path $src) { Copy-Item $src -Destination $Backup -Recurse -Force }
}
Say "Backup: $Backup"

function Restore-Backup {
    Say "Restoring the previous files from $Backup ..."
    & robocopy $Backup $App /E /IS /IT /R:1 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
}

Step "Copying the $PatchVersion application files"
try {
    Get-ChildItem (Join-Path $App "qa_platform") -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    & robocopy (Join-Path $Here "app") $App /E /IS /IT /R:2 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "robocopy could not copy the files (exit code $LASTEXITCODE). Is a file still open?" }

    $env:QA_HOME = $Data
    Push-Location $App
    $ErrorActionPreference = "Continue"   # Windows PowerShell 5.1 turns a native command's stderr into an error
    try { $now = (& $Py -E -s -c "import qa_platform, qa_platform.main; print(qa_platform.__version__)" 2>&1 | Select-Object -Last 1) }
    finally { Pop-Location; $ErrorActionPreference = "Stop" }
    if ("$now".Trim() -ne $PatchVersion) { throw "The new files do not start correctly: $now" }
    Say "Application files: version $now loads correctly."
} catch {
    Restore-Backup
    try { Stop-Transcript | Out-Null } catch { }
    Fail "$($_.Exception.Message) The previous version was restored. Log: $Log"
}

$ErrorActionPreference = "Continue"   # from here on a problem is reported, never half-applied
$list = Join-Path $env:TEMP "qa-patch-files-$Stamp.txt"
$appSrc = (Resolve-Path (Join-Path $Here "app")).Path
Get-ChildItem $appSrc -Recurse -File | ForEach-Object { $_.FullName.Substring($appSrc.Length + 1) } | Set-Content -Path $list -Encoding UTF8
& $Py -E -s (Join-Path $Here "patch_helper.py") manifest --app $App --files $list
Remove-Item $list -ErrorAction SilentlyContinue

# --- 4. Offline voice agent --------------------------------------------------------------------------------------
Step "Checking the offline voice agent"
$voiceArgs = @("voice", "--app", $App, "--data", $Data, "--patch", $Here)
if ($VoiceModel) { $voiceArgs += @("--model", $VoiceModel) }
& $Py -E -s (Join-Path $Here "patch_helper.py") @voiceArgs
$VoiceOk = ($LASTEXITCODE -eq 0)

# --- 5. Start and check ------------------------------------------------------------------------------------------
$Health = $null
if (-not $NoStart) {
    Step "Starting QA Enterprise AI"
    $launcher = Join-Path $Root "START_QA_PLATFORM.cmd"
    if (-not (Test-Path $launcher)) { $launcher = Join-Path $App "START_QA_PLATFORM.cmd" }
    Start-Process -FilePath $launcher -WorkingDirectory (Split-Path $launcher -Parent)
    for ($i = 0; $i -lt 45 -and -not $Health; $i++) {
        Start-Sleep -Seconds 2
        try { $Health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 3 } catch { }
    }
}

Step "Result"
if ($Health) { Say "Running: http://127.0.0.1:$Port/  version $($Health.version)" }
elseif ($NoStart) { Say "Patched to $PatchVersion. Start it with $Root\START_QA_PLATFORM.cmd." }
else { Say "Patched to $PatchVersion, but the health check did not answer within 90 seconds. Look at the application window." }
if ($VoiceOk) { Say "Offline voice agent: READY (open Voice Commands and press the microphone)." }
else {
    Write-Host "Offline voice agent: NOT READY. Run this patch again with" -ForegroundColor Yellow
    Write-Host "  -VoiceModel ""<path to AIAgenticTestAgent-Offline-*.zip or vosk-model-small-en-us-0.15.zip>""" -ForegroundColor Yellow
}
Say "Press Ctrl+F5 once in the browser so it loads the new pages."
Say "Backup of the old files: $Backup"
Say "Log: $Log"
try { Stop-Transcript | Out-Null } catch { }
